package com.letsgo.firebaseapp

data class User(
    var username: String = "",
    var email : String ="",
    var userId : String="",
    var profilePic : String? = null
){

}